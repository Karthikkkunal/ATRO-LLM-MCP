{pkgs}: {
  deps = [
    pkgs.redis
  ];
}
